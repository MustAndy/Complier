﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Bll;
using Project_for_CS108.App_Code.Model;

namespace Project_for_CS108
{
    public partial class Login_Page : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (this.DropDownList1.SelectedValue == "student")
            {
                BStudent bll = new BStudent();
                bool affacted = bll.CheckUser(TextBox1.Text, TextBox2.Text);
                if (affacted)
                {
                    Session["sname"] = TextBox1.Text.ToString();
                    Response.Write("<script>alert('Success！');location='Web/Student/StudentStart.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Wrong username or password! Please try again!');location='Login_page.aspx'</script>");
                }
            }
            if (this.DropDownList1.SelectedValue == "teacher")
            {
                BTeacher bll = new BTeacher();
                bool affacted = bll.CheckUser(TextBox1.Text, TextBox2.Text);
                if (affacted)
                {
                    Session["tname"] = TextBox1.Text.ToString();
                    Response.Write("<script>alert('Success！');location='Web/Teacher/TeacherStart.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Wrong username or password! Please try again!');location='Login_page.aspx'</script>");
                }
            }
            if (this.DropDownList1.SelectedValue == "admin")
            {
                BAdmin bll = new BAdmin();
                bool affacted = bll.CheckUser(TextBox1.Text, TextBox2.Text);
                if (affacted)
                {
                    Session["aname"] = TextBox1.Text.ToString();
                    Response.Write("<script>alert('Success！');location='Web/Admin/AdminStart.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Wrong username or password! Please try again!');location='Login_page.aspx'</script>");
                }

            }
        }
        protected void Button2_Click1(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            DropDownList1.ClearSelection();

        }
    }
}