﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Bll;
namespace Project_for_CS108.Web.Admin
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Class newdistribute = new Class(
                Convert.ToString(DropDownList1.SelectedValue),
                Convert.ToString(DropDownList2.SelectedValue),
                Convert.ToString(DropDownList1.SelectedItem),
                "null");
            BClass bdistribute = new BClass();
            bdistribute.TeacherInsertDistribute(newdistribute);
            Response.Write("<script>alert('See distribute！');location='.././Teacher/TeacherStart.aspx'</script>");
        }
    }
}