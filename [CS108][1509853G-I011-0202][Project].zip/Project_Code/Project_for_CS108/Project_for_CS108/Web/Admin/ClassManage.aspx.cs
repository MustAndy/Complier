﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Bll;
using Project_for_CS108.App_Code.Model;

namespace Project_for_CS108.Web.Admin
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Class NewClass = new Class(
               Convert.ToString(TextBox1.Text),
               Convert.ToString(TextBox3.Text),
               Convert.ToString(DropDownList1.SelectedValue));
               
            BClass bClass = new BClass();
            bClass.AdminInsertClass(NewClass);
            Response.Write("<script>alert('Success！');location='./AdminStart.aspx'</script>");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Class NewClass = new Class(
    Convert.ToString(TextBox1.Text));
            BClass bClass = new BClass();
            bClass.AdminDeleteClass(NewClass);
            Response.Write("<script>alert('Success！');location='./AdminStart.aspx'</script>");
        }
    }
}