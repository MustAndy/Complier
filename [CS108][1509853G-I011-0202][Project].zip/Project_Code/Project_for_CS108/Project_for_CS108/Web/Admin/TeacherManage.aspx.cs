﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Bll;
using Project_for_CS108.App_Code.Model;
namespace Project_for_CS108.Web.Admin
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            teacher NewTeacher = new teacher(
                Convert.ToString(TextBox1.Text),
                Convert.ToString(TextBox2.Text),               
                Convert.ToString(TextBox4.Text),
                Convert.ToString(TextBox5.Text));
            BTeacher bstu = new BTeacher();
            bstu.AdminInsertTeacher(NewTeacher);
            Response.Write("<script>alert('Success！');location='./AdminStart.aspx'</script>");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            teacher NewTeacher = new teacher(
                Convert.ToString(TextBox1.Text));
            BTeacher bstu = new BTeacher();
            bstu.AdminDeleteTeacher(NewTeacher);
            Response.Write("<script>alert('Success！');location='./AdminStart.aspx'</script>");
        }
    }
}