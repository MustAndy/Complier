﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project_for_CS108.Web.Admin
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["aname"] == null)
            {
                Label1.Text = Session["tname"].ToString();
                HyperLink4.Visible = false;
                HyperLink6.Visible = false;
            }
            else if (Session["tname"] == null) Label1.Text = Session["aname"].ToString();
            
        }
        protected void LinkButton1_Click(object sender,EventArgs e)
        {

        }
    }
}