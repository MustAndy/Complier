﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Bll;
namespace Project_for_CS108.Web.Teacher
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{            
        //   Assignment assi = new Assignment(
        //       Convert.ToString(Session["tname"]),
        //        Convert.ToString(OutlineText.Text),
        //       Convert.ToString(DropDownList1.SelectedValue),
        //       Convert.ToDateTime(System.DateTime.Now),
        //       Convert.ToDateTime(Calendar1.SelectedDate));

        //    BAssignment bassi = new BAssignment();

        //    bassi.InsertAssignment(assi);
        //    Response.Write("<script>alert('Success！');location='./TeacherStart.aspx'</script>");
        //}

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Session["classid"] = DropDownList1.SelectedValue;
            Session["DueDate"] = Calendar1.SelectedDate;
            Session["AssignmentName"] = TextBox1.Text;
            Session["totalmark"] = TextBox2.Text;
            Response.Write("<script>alert('Success！');location='./QuestionPublish.aspx'</script>");
        }


        //protected void DropDownList2_TextChanged(object sender, EventArgs e)
        //{
        //    Label4.Text = Session["tname"].ToString();
        //    OutlineText.Visible = false;
        //    Q1Text.Visible = false;
        //    Q2Text.Visible = false;
        //    Q3Text.Visible = false;
        //    Q4Text.Visible = false;
        //    Q5Text.Visible = false;


        //    //switch (DropDownList2.SelectedValue)
        //    //{
        //    //    case "Outline":
        //    //        OutlineText.Visible = true; break;
        //    //    case "Q1":
        //    //        Q1Text.Visible = true; break;
        //    //    case "Q2":
        //    //        Q2Text.Visible = true; break;
        //    //    case "Q3":
        //    //        Q3Text.Visible = true; break;
        //    //    case "Q4":
        //    //        Q4Text.Visible = true; break;
        //    //    case "Q5":
        //    //        Q5Text.Visible = true; break;
        //    //}
        //}

        //protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    Label3.Text = DropDownList2.SelectedValue;
        //}
    }
}