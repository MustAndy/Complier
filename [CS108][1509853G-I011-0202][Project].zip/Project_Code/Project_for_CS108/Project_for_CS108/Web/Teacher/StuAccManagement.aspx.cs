﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Bll;

namespace Project_for_CS108.Web.Teacher
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            student NewStu = new student(
                Convert.ToString(TextBox1.Text),
                Convert.ToString(TextBox2.Text),
                Convert.ToString(TextBox3.Text),
                Convert.ToString(TextBox4.Text),
                Convert.ToString(TextBox5.Text));
            BStudent bstu = new BStudent();
            bstu.TeacherInsertStudent(NewStu);
            Response.Write("<script>alert('Success！');location='./TeacherStart.aspx'</script>");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            student newStu = new student(
                Convert.ToString(TextBox1.Text));
            BStudent bstu = new BStudent();
            bstu.TeacherDeleteStudent(newStu);
            Response.Write("<script>alert('Success！');location='./TeacherStart.aspx'</script>");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('See distribute！');location='.././Admin/ClassDistribute.aspx'</script>");
        }
    }
}