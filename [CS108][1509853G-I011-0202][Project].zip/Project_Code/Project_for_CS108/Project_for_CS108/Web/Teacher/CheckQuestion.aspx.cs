﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Bll;

namespace Project_for_CS108.Web.Teacher
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            int totalMarks = 0;
            int[] mark = new int[5];
            string[] answerID = new string[5];
            answerID[0] = Session["answer1"].ToString();
            answerID[1] = Session["answer2"].ToString();
            answerID[2] = Session["answer3"].ToString();
            answerID[3] = Session["answer4"].ToString();
            answerID[4] = Session["answer5"].ToString();
            for (int i=0;i<5;i++)
            {
                mark[i]= Convert.ToInt32(((TextBox)(GridView1.Rows[i].Cells[3].FindControl("TextBox1"))).Text);
                Grade questionGrade = new Grade(
                    Convert.ToString(answerID[i]),
                    Convert.ToInt32(mark[i]));
                BGrade bquestionGrade = new BGrade();
                bquestionGrade.TeacherMarkGrade(questionGrade);
                totalMarks += mark[i];
            }

            Grade assiGrade = new Grade(
                Convert.ToString(Session["answerID"]),
                Convert.ToInt32(totalMarks),
                Convert.ToString(Session["tname"]),
                Convert.ToString(TextBox2.Text));
            BGrade bassiGrade = new BGrade();
            bassiGrade.TeacherMarkAssignment(assiGrade);

            Response.Write("<script>alert('Success！');location='./TeacherStart.aspx'</script>");
        }
    }
}