﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Bll;

namespace Project_for_CS108.Web.Teacher
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        string assignmentId;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            DateTime now = System.DateTime.Now;
            string code = now.GetHashCode().ToString().Substring(1, 5);
            assignmentId = code + '-' + Session["tname"] + '-' + Session["classid"];
            Assignment assi = new Assignment(
                Convert.ToString(assignmentId),
                Convert.ToString(Session["tname"]),
                Convert.ToString(Session["AssignmentName"]),
                Convert.ToString(Session["classid"]),
                Convert.ToString(OutlineText.Text),
                Convert.ToDateTime(now),
                Convert.ToDateTime(Session["DueDate"]),
                Convert.ToInt32(Session["totalmark"]));

            BAssignment bassi = new BAssignment();
            bassi.TeacherInsertAssignment(assi);

            string[]question = new string[5];
            question[0] = Q1Text.Text;
            question[1] = Q2Text.Text;
            question[2] = Q3Text.Text;
            question[3] = Q4Text.Text;
            question[4] = Q5Text.Text;
            string[] weights = new string[5];
            weights[0] = TextBox1.Text;
            weights[1] = TextBox2.Text;
            weights[2] = TextBox3.Text;
            weights[3] = TextBox4.Text;
            weights[4] = TextBox5.Text;
            for (int i = 0;i<5;i++)
            {
                Question ques = new Question(
                    Convert.ToString(assignmentId),
                    Convert.ToString(assignmentId+'-'+(i+1).ToString()+'-'+'0'),
                    Convert.ToString(question[i]),
                    Convert.ToInt32(weights[i]),
                    Convert.ToInt32(0)
                    );
                BQuestion bques = new BQuestion();
                bques.TeacherInsertQuestion(ques);
            }
            
            
            Response.Write("<script>alert('Success！');location='./TeacherStart.aspx'</script>");
        }
    }
}