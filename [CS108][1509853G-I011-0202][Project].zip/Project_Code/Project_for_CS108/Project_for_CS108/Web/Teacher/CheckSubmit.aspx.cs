﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project_for_CS108.Web.Teacher
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string answerID =  DetailsView1.Rows[0].Cells[1].Text.ToString();
            Session["AnswerID"] = answerID.ToString();
            Session["answer1"] = (answerID + "-1-0").ToString();
            Session["answer2"] = (answerID + "-2-0").ToString();
            Session["answer3"] = (answerID + "-3-0").ToString();
            Session["answer4"] = (answerID + "-4-0").ToString();
            Session["answer5"] = (answerID + "-5-0").ToString();
            
            Response.Write("<script>alert('Success！');location='./CheckQuestion.aspx'</script>");
        }
    }
}