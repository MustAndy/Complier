﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project_for_CS108.Web.Student
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["stuClass"] = DropDownList2.SelectedValue.ToString();
        }
        
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {           
            Session["stuClass"] = DropDownList2.SelectedValue.ToString();
                       
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["assignment"] = DropDownList3.SelectedValue.ToString();
            Session["question1"] = (DropDownList3.SelectedValue + "-1-0").ToString();
            Session["question2"] = (DropDownList3.SelectedValue + "-2-0").ToString();
            Session["question3"] = (DropDownList3.SelectedValue + "-3-0").ToString();
            Session["question4"] = (DropDownList3.SelectedValue + "-4-0").ToString();
            Session["question5"] = (DropDownList3.SelectedValue + "-5-0").ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            Session["Assiname"] = DetailsView1.Rows[1].Cells[1].Text.ToString();
            Response.Write("<script>alert('Please be careful~');location = './QuestionToDo.aspx'</script>");
        }

    }
}