﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Bll;

namespace Project_for_CS108.Web.Student
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DetailsView1.Visible = true;
            DetailsView2.Visible = false;
            DetailsView3.Visible = false;
            DetailsView4.Visible = false;
            DetailsView5.Visible = false;
            TextBox1.Visible = true;
            TextBox2.Visible = false;
            TextBox3.Visible = false;
            TextBox4.Visible = false;
            TextBox5.Visible = false;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedValue=="q1")
            {
                DetailsView1.Visible = true;
                DetailsView2.Visible = false;
                DetailsView3.Visible = false;
                DetailsView4.Visible = false;
                DetailsView5.Visible = false;
                TextBox1.Visible = true;
                TextBox2.Visible = false;
                TextBox3.Visible = false;
                TextBox4.Visible = false;
                TextBox5.Visible = false;
            }
            else if (DropDownList1.SelectedValue == "q2")
            {
                DetailsView1.Visible = false;
                DetailsView2.Visible = true;
                DetailsView3.Visible = false;
                DetailsView4.Visible = false;
                DetailsView5.Visible = false;
                TextBox1.Visible = false;
                TextBox2.Visible = true;
                TextBox3.Visible = false;
                TextBox4.Visible = false;
                TextBox5.Visible = false;
            }
            else if (DropDownList1.SelectedValue == "q3")
            {
                DetailsView1.Visible = false;
                DetailsView2.Visible = false;
                DetailsView3.Visible = true;
                DetailsView4.Visible = false;
                DetailsView5.Visible = false;
                TextBox1.Visible = false;
                TextBox2.Visible = false;
                TextBox3.Visible = true;
                TextBox4.Visible = false;
                TextBox5.Visible = false;
            }
            else if (DropDownList1.SelectedValue == "q4")
            {
                DetailsView1.Visible = false;
                DetailsView2.Visible = false;
                DetailsView3.Visible = false;
                DetailsView4.Visible = true;
                DetailsView5.Visible = false;
                TextBox1.Visible = false;
                TextBox2.Visible = false;
                TextBox3.Visible = false;
                TextBox4.Visible = true;
                TextBox5.Visible = false;
            }
            else if (DropDownList1.SelectedValue == "q5")
            {
                DetailsView1.Visible = false;
                DetailsView2.Visible = false;
                DetailsView3.Visible = false;
                DetailsView4.Visible = false;
                DetailsView5.Visible = true;
                TextBox1.Visible = false;
                TextBox2.Visible = false;
                TextBox3.Visible = false;
                TextBox4.Visible = false;
                TextBox5.Visible = true;
            }
        }
        string assignmentId;
        protected void Button1_Click(object sender, EventArgs e)
        {
            DateTime now = System.DateTime.Now;
            string code = now.GetHashCode().ToString().Substring(1, 5);
            assignmentId = code + '-' + Session["sname"] + '-' + Session["stuClass"];
            Assignment StuAssi = new Assignment(
                Convert.ToString(assignmentId),
                Convert.ToString(Session["Assiname"]),
                Convert.ToString(Session["assignment"]),
                Convert.ToDateTime(now),
                Convert.ToDateTime(now),
                Convert.ToString(Session["stuClass"]),
                Convert.ToString(Session["sname"]));
            BAssignment bStuAssi = new BAssignment();
            bStuAssi.StudentInsertAssignment(StuAssi);

            string[] questionAnswer = new string[5];
            questionAnswer[0] = TextBox1.Text;
            questionAnswer[1] = TextBox2.Text;
            questionAnswer[2] = TextBox3.Text;
            questionAnswer[3] = TextBox4.Text;
            questionAnswer[4] = TextBox5.Text;
            string[] questionText = new string[5];
            string[] questionWeight = new string[5];
            questionText[0] = DetailsView1.Rows[0].Cells[1].Text.ToString();
            questionText[1] = DetailsView2.Rows[0].Cells[1].Text.ToString();
            questionText[2] = DetailsView3.Rows[0].Cells[1].Text.ToString();
            questionText[3] = DetailsView4.Rows[0].Cells[1].Text.ToString();
            questionText[4] = DetailsView5.Rows[0].Cells[1].Text.ToString();
            questionWeight[0] = DetailsView1.Rows[1].Cells[1].Text.ToString();
            questionWeight[1] = DetailsView2.Rows[1].Cells[1].Text.ToString();
            questionWeight[2] = DetailsView3.Rows[1].Cells[1].Text.ToString();
            questionWeight[3] = DetailsView4.Rows[1].Cells[1].Text.ToString();
            questionWeight[4] = DetailsView5.Rows[1].Cells[1].Text.ToString();

            for (int i = 0; i<5;i++)
            {
                Question stuAnswer = new Question(
                    Convert.ToString(assignmentId),
                    Convert.ToString(assignmentId + '-' + (i + 1).ToString() + '-' + '1'),
                    Convert.ToString(questionText[i]),
                    Convert.ToInt32(questionWeight[i]),
                    Convert.ToString(Session["sname"]),
                    Convert.ToString(questionAnswer[i]));
                BQuestion bstuAnswer = new BQuestion();
                bstuAnswer.StudentInsertQuestion(stuAnswer);

            }
            Response.Write("<script>alert('Success');location = './StudentStart.aspx'</script>");
        }
    }
}