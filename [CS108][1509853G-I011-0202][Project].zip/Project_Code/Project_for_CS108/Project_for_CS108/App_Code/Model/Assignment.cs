﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_for_CS108.App_Code.Model
{
    public class Assignment
    {
        private string assignmentname;
        private string assignmentid;
        private string submitassiid;
        private DateTime startdate;
        private DateTime duedate;
        private string comment;
        private int totalmark;
        private string classid;
        private string studentid;
        private string teacherid;
        private string outline;

        public string AssignmentName
        {
            get { return assignmentname; }
            set { assignmentname = value; }
        }
        public string AssignmentID
        {
            get { return assignmentid; }
            set { assignmentid = value; }
        }
        public DateTime StartDate
        {
            get { return startdate; }
            set { startdate = value; }
        }
        public DateTime DueDate
        {
            get { return duedate; }
            set { duedate = value; }
        }
        public string Comment
        {
            get { return comment; }
            set { comment = value; }
        }
        public int TotalMark
        {
            get { return totalmark; }
            set { totalmark = value; }
        }
        public string ClassID
        {
            get { return classid; }
            set { classid = value; }
        }
        public string StudentID
        {
            get { return studentid; }
            set { studentid = value; }
        }
        public string TeacherID
        {
            get { return teacherid; }
            set { teacherid = value; }
        }
        public string Outline
        {
            get { return outline; }
            set { outline = value; }
        }
        public string SubmitAssiID
        {
            get { return submitassiid; }
            set { submitassiid = value; }
        }
        public Assignment(string _AssignmentID,string _teacherid,string _assignmentName,string _outline, string _classid,DateTime _startdate, DateTime _duedate,int _totalmark)
        {
            this.AssignmentID = _AssignmentID;
            this.teacherid = _teacherid;
            this.assignmentname = _assignmentName;
            this.outline = _outline;
            this.classid = _classid;
            this.startdate = _startdate;
            this.duedate = _duedate;
            this.totalmark = _totalmark;
        }
        public Assignment(string _AssignmentID, string _assignmentName,string _submitAssiid,  DateTime _startdate, DateTime _duedate, string _classid,string _studentID)
        {
            this.AssignmentID = _AssignmentID;
            this.assignmentname = _assignmentName;
            this.submitassiid = _submitAssiid;
            this.startdate = _startdate;
            this.duedate = _duedate;
            this.studentid = _studentID;
            this.classid = _classid;

        }
    }
}