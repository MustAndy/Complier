﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_for_CS108.App_Code.Model
{
    public class Class
    {
        private string ClassID;
        private string TeacherID;
        private string ClassName;
        private string StudentID;
        public string Cid
        {
            get { return ClassID; }
            set { ClassID = value; }
        }
        public string Cname
        {
            get { return ClassName; }
            set { ClassName = value; }
        }
        public string tid
        {
            get { return TeacherID; }
            set { TeacherID = value; }
        }
        public string sid
        {
            get { return StudentID; }
            set { StudentID = value; }
        }
        public Class() { }

        public Class(string _cid, string _cname, string _tid)
        {
            this.ClassName = _cname;
            this.TeacherID = _tid;
            this.ClassID = _cid;
        }
        public Class(string _cid)
        {
            this.ClassID = _cid;
        }

        public Class(string _cid, string _sid, string _cname,string adding)
        {
            this.ClassName = _cname;
            this.StudentID = _sid;
            this.ClassID = _cid;
        }
        
    }
}