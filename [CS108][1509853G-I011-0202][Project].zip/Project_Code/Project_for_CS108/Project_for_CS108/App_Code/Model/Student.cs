﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_for_CS108.App_Code.Model
{
    public class student
    {
        private string sID;
        private string sName;
        private string sMajor;
        private string sPassword;
        private string sEmail;
        public string SID
        {
            get { return sID; }
            set { sID = value; }
        }
        public string SName
        {
            get { return sName; }
            set { sName = value; }
        }
        public string SMajor
        {
            get { return sMajor; }
            set { sMajor = value; }
        }
        public string Spwd
        {
            get { return sPassword; }
            set { sPassword = value; }
        }
        public string Semail
        {
            get { return sEmail; }
            set { sEmail = value; }
        }

        public student()
        { }
        public student(string _sid, string _sname, string _smajor, string _spwd,string _semail)
        {
            this.sID = _sid;
            this.sName = _sname;
            this.sMajor = _smajor;
            this.sPassword = _spwd;
            this.sEmail = _semail;
        }

        public student(string _sid)
        {
            this.sID = _sid;
        }
    }
}