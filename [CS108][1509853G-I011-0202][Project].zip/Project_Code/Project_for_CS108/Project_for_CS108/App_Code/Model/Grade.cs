﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_for_CS108.App_Code.Model
{
    public class Grade
    {
        private string AssignmentID;
        private string QuestionID;
        private int QuestionMarks;
        private int TotalMarks;
        private string Comments;
        private string TeacherID;

        public Grade (string _questionid,int _questionmarks)
        {            
            this.QuestionID = _questionid;
            this.QuestionMarks = _questionmarks;
        }

        public Grade(string _assiid, int _totalmarks ,string _teacherid,string _comment)
        {
            this.AssignmentID = _assiid;
            this.TotalMarks = _totalmarks;
            this.TeacherID = _teacherid;
            this.Comments = _comment;
        }

        public string assiID
        {
            get { return AssignmentID; }
            set { AssignmentID = value; }
        }
        public string quesID
        {
            get { return QuestionID; }
            set { QuestionID = value; }
        }
        public int questionmark
        {
            get { return QuestionMarks; }
            set { QuestionMarks = value; }
        }
        public int totalmark
        {
            get { return TotalMarks; }
            set { TotalMarks = value; }
        }
        public string comment
        {
            get { return Comments; }
            set { Comments = value; }
        }
        public string teacherid
        {
            get { return TeacherID; }
            set { TeacherID = value; }
        }
    }
}