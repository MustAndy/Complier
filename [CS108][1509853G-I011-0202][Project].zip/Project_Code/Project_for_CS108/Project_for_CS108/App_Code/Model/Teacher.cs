﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_for_CS108.App_Code.Model
{
    public class teacher
    {
        private string TeacherID;
        private string TeacherName;
        private string TeacherEmail;
        private string TeacherPassword; 

        public string TID
        {
            get { return TeacherID; }
            set { TeacherID = value; }
        }
        public string Tname
        {
            get { return TeacherName; }
            set { TeacherName = value; }
        }

        public string Tpwd
        {
            get { return TeacherPassword; }
            set { TeacherPassword = value; }
        }
        public string Temail
        {
            get { return TeacherEmail; }
            set { TeacherEmail = value; }
        }

        public teacher()
        { }

        public teacher(string _tid, string _tname, string _tpwd,string _temail)
        {
            this.TeacherID = _tid;
            this.TeacherPassword = _tpwd;
            this.TeacherName = _tname;
            this.TeacherEmail = _temail;

        }
        public teacher(string _tid)
        {
            this.TeacherID = _tid;
        }
    }
}