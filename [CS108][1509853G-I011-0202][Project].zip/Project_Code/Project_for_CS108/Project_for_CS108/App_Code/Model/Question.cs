﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project_for_CS108.App_Code.Model
{
    public class Question
    {
        private string AssignmentID;
        private string QuestionID;
        private string QuestionText;
        private int weight;

        private string StudentID;
        private string QuestionAnswer;
        private int marks;

        private int submitted;


        public Question(string _assignmentID, string _questionID,string _questionText, int _weight, int _submintted )
        {
            this.AssignmentID = _assignmentID;
            this.QuestionID = _questionID;
            this.QuestionText = _questionText;
            this.weight = _weight;            
            this.submitted = _submintted;
         }
        public Question(string _assignmentID, string _questionID, string _questionText, int _weight, string _studentID, string _questionAnswer)
        {
            this.AssignmentID = _assignmentID;
            this.QuestionID = _questionID;
            this.QuestionText = _questionText;
            this.weight = _weight;
            this.StudentID = _studentID;
            this.QuestionAnswer = _questionAnswer;

        }
            
            public Question()
        { }

        public string assiID
        {
            get { return AssignmentID; }
            set { AssignmentID = value; }
        }
        public string quesID
        {
            get { return QuestionID; }
            set { QuestionID = value; }
        }
        public string quesText
        {
            get { return QuestionText; }
            set { QuestionText = value; }
        }
        public int weights
        {
            get { return weight; }
            set { weight = value; }
        }
        public string stuID
        {
            get { return StudentID; }
            set { StudentID = value; }
        }
        public string quesAnswer
        {
            get { return QuestionAnswer; }
            set { QuestionAnswer = value; }
        }
        public int marking
        {
            get { return marks; }
            set { marks = value; }
        }
        public int issubmit
        {
            get { return submitted; }
            set { submitted = value; }
        }
    }
}