﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using Project_for_CS108.App_Code.Model;
namespace Project_for_CS108.App_Code.Dal
{
    public class DStudent
    {
        #region///检测用户名和密码///

        public bool CheckUser(string nName, string nPass)
        {

            bool IsBool;
            SqlParameter[] paras = { new SqlParameter("@sno", SqlDbType.VarChar, 50), new SqlParameter("@spwd", SqlDbType.VarChar, 50) };
            paras[0].Value = nName;
            paras[1].Value = nPass;
            string sqlText = "SELECT count(*) FROM [Student] WHERE StudentID=@sno AND StudentPassword=@spwd ";
            try
            {

                int txtRows = int.Parse(SQLHelper.ExecuteSclare(SQLHelper.txtConnecttionString, CommandType.Text, sqlText, paras).ToString());
                if (txtRows > 0)
                {

                    IsBool = true;

                }
                else
                {

                    IsBool = false;

                }
                return IsBool;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
        #endregion
        #region///添加新数据///
        public int TeacherInsertStudent(student mod)
        {

            int rows;
            SqlParameter[] paras = { new SqlParameter("@Studentid", SqlDbType.VarChar,50),
                                     new SqlParameter("@Studentname", SqlDbType.VarChar,50),
                                     new SqlParameter("@Studentmajor", SqlDbType.VarChar,50),
                                     new SqlParameter("@Studentpassword", SqlDbType.VarChar,50),
                                     new SqlParameter("@Studentemails", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int),
            };
            paras[0].Value = mod.SID;
            paras[1].Value = mod.SName;
            paras[2].Value = mod.SMajor;
            paras[3].Value = mod.Spwd;
            paras[4].Value = mod.Semail;         
            paras[5].Value = 0;

            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "TeacherInsertStudent", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
        public int TeacherDeleteStudent(student mod)
        {

            int rows;
            SqlParameter[] paras = { new SqlParameter("@Studentid", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int),

            };
            paras[0].Value = mod.SID;
            paras[1].Value = 0;
            
            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "TeacherDeleteStudent", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
        #endregion


    }
}