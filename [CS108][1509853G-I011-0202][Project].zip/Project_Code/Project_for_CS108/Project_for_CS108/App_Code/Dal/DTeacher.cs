﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using Project_for_CS108.App_Code.Model;
namespace Project_for_CS108.App_Code.Dal
{
    public class DTeacher
    {
        #region///检测用户名和密码///

        public bool CheckUser(string nName, string nPass)
        {

            bool IsBool;
            SqlParameter[] paras = { new SqlParameter("@tid", SqlDbType.VarChar, 10), new SqlParameter("@tpwd", SqlDbType.VarChar, 50) };
            paras[0].Value = nName;
            paras[1].Value = nPass;
            string sqlText = "SELECT count(*) FROM [Teacher] WHERE TeacherID=@tid AND TeacherPassword=@tpwd ";
            try
            {

                int txtRows = int.Parse(SQLHelper.ExecuteSclare(SQLHelper.txtConnecttionString, CommandType.Text, sqlText, paras).ToString());
                if (txtRows > 0)
                {

                    IsBool = true;

                }
                else
                {

                    IsBool = false;

                }
                return IsBool;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
        #endregion
        #region///添加新数据///
        public int AdminInsertTeacher(teacher mod)
        {

            int rows;
            SqlParameter[] paras = { new SqlParameter("@Teacherid", SqlDbType.VarChar,50),
                                     new SqlParameter("@TeacherName", SqlDbType.VarChar,50),
                                     new SqlParameter("@Teacherpassword", SqlDbType.VarChar,50),
                                     new SqlParameter("@Teacheremails", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int),
          
            };
            paras[0].Value = mod.TID;
            paras[1].Value = mod.Tname;
            paras[2].Value = mod.Tpwd;
            paras[3].Value = mod.Temail;
            paras[4].Value = 0;
            
            try
            {
                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "AdminInsertTeacher", paras);
                return rows;
            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
        #endregion
        public int AdminDeleteTeacher(teacher mod)
        {

            int rows;
            SqlParameter[] paras = { new SqlParameter("@Teacgerid", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int)   
            };

            paras[0].Value = mod.TID;
            paras[1].Value = 0;

            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "AdminDeleteTeacher", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
    }
}