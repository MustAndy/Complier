﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Project_for_CS108.App_Code.Model;
using System.Data.SqlClient;
using System.Data;
namespace Project_for_CS108.App_Code.Dal
{
    public class DQuestion
    {
        #region ///添加数据///
        public int TeacherInsertQuestion(Question mod)
        {
            int rows;
            SqlParameter[] paras = { new SqlParameter("@Assignmentid", SqlDbType.VarChar,50),
                                     new SqlParameter("@Questionid", SqlDbType.VarChar,50),
                                      new SqlParameter("@QuestionText", SqlDbType.VarChar ,50),
                                     new SqlParameter("@Weight", SqlDbType.Int),
                                      new SqlParameter ("@submitted",SqlDbType.Int),
                                      new SqlParameter("@NumRows",SqlDbType.Int)

            };
            paras[0].Value = mod.assiID;
            paras[1].Value = mod.quesID;
            paras[2].Value = mod.quesText;
            paras[3].Value = mod.weights;
            paras[4].Value = mod.issubmit;
            paras[5].Value = 0;
            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "TeacherInsertQuestion", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

 public int StudentInsertQuestion(Question mod)
        {
            int rows;
            SqlParameter[] paras = { new SqlParameter("@Assignmentid", SqlDbType.VarChar,50),
                                     new SqlParameter("@Questionid", SqlDbType.VarChar,50),
                                      new SqlParameter("@QuestionText", SqlDbType.VarChar ,50),
                                     new SqlParameter("@Weight", SqlDbType.Int),
                                      new SqlParameter ("@studentid",SqlDbType.VarChar,50),
                                      new SqlParameter ("@questionAnswer",SqlDbType.VarChar,50),
                                      new SqlParameter("@NumRows",SqlDbType.Int)

            };
            paras[0].Value = mod.assiID;
            paras[1].Value = mod.quesID;
            paras[2].Value = mod.quesText;
            paras[3].Value = mod.weights;
            paras[4].Value = mod.stuID;
            paras[5].Value = mod.quesAnswer;
            paras[6].Value = 0;
            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "StudentInsertQuestion", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
        #endregion
    }
}
