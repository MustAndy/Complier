﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Project_for_CS108.App_Code.Model;
namespace Project_for_CS108.App_Code.Dal
{
    public class DClass
    {

        #region///添加新数据///
        public int AdminDeleteClass(Class mod)
        {

            int rows;
            SqlParameter[] paras = { 
                                     new SqlParameter("@Classid", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int)  
            
            };
            paras[0].Value = mod.Cid;
            paras[1].Value = 0;

            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "AdminDeleteClass", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
        #endregion
      public int AdminInsertClass(Class mod)
        {

            int rows;
            SqlParameter[] paras = { 
                                     new SqlParameter("@Classid", SqlDbType.VarChar,50),
                                     new SqlParameter("@Teacherid", SqlDbType.VarChar,50), 
                                     new SqlParameter("@ClassName", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int)  
            };
            paras[0].Value = mod.Cid;
            paras[1].Value = mod.tid;
            paras[2].Value = mod.Cname;
            paras[3].Value = 0;

            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "AdminInsertClass", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

        public int TeacherInsertDistribute(Class mod)
        {

            int rows;
            SqlParameter[] paras = {
                                     new SqlParameter("@Classid", SqlDbType.VarChar,50),
                                     new SqlParameter("@Studentid", SqlDbType.VarChar,50),
                                     new SqlParameter("@ClassName", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int)
            };
            paras[0].Value = mod.Cid;
            paras[1].Value = mod.sid;
            paras[2].Value = mod.Cname;
            paras[3].Value = 0;

            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "TeacherInsertDistribute", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
    }
}