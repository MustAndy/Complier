﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Project_for_CS108.App_Code.Model;
using System.Data.SqlClient;
using System.Data;
namespace Project_for_CS108.App_Code.Dal
{
    public class DGrade
    {
        
        public int TeacherMarkGrade(Grade mod)
        {

            int rows;
            SqlParameter[] paras = { 
                                     new SqlParameter("@Questionid", SqlDbType.VarChar,50),
                                     new SqlParameter("@QuestionMarks", SqlDbType.Int),                                      
                                     new SqlParameter("@NumRows", SqlDbType.Int),
                                  
            
            };
            paras[0].Value = mod.quesID;
            paras[1].Value = mod.questionmark; 
            paras[2].Value = 0;
           
            try
            {

                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "TeacherMarkGrade", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }

        public int TeacherMarkAssignment(Grade mod)
        {

            int rows;
            SqlParameter[] paras = {
                                     new SqlParameter("@assignmentID", SqlDbType.VarChar,50),
                                     new SqlParameter("@totalMarks", SqlDbType.Int),
                                     new SqlParameter("@comment", SqlDbType.VarChar,50),
                                     new SqlParameter("@teacherid", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int),


            };
            paras[0].Value = mod.assiID;
            paras[1].Value = mod.totalmark;
            paras[2].Value = mod.comment;
            paras[3].Value = mod.teacherid;
            paras[4].Value = 0;

            try
            {
                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "TeacherMarkAssignment", paras);
                return rows;
            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
    }
    
}