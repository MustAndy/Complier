﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Project_for_CS108.App_Code.Model;
using System.Data.SqlClient;
using System.Data;

namespace Project_for_CS108.App_Code.Dal
{
    public class DAssignment
    {

        public int TeacherInsertAssignment(Assignment mod)
        {
            int rows;
            SqlParameter[] paras = { new SqlParameter("@Assignmentid", SqlDbType.VarChar ,50),
                                     new SqlParameter("@AssignmentName", SqlDbType.VarChar ,50),
                                     new SqlParameter("@teacherid", SqlDbType.VarChar ,50),
                                     new SqlParameter("@outline", SqlDbType.VarChar,50),
                                     new SqlParameter("@classid", SqlDbType.VarChar,50),
                                     new SqlParameter("@StartDate",SqlDbType.DateTime),
                                     new SqlParameter("@DueDate",SqlDbType.DateTime),
                                     new SqlParameter("@TotalMark", SqlDbType.Int),
                                     new SqlParameter("@NumRows",SqlDbType.Int)
            };
            paras[0].Value = mod.AssignmentID;
            paras[1].Value = mod.AssignmentName;
            paras[2].Value = mod.TeacherID;
            paras[3].Value = mod.ClassID;
            paras[4].Value = mod.Outline;
            paras[5].Value = mod.StartDate;
            paras[6].Value = mod.DueDate;
            paras[7].Value = mod.TotalMark;
            paras[8].Value = 0;

            try
            {
                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "TeacherInsertAssignment", paras);
                return rows;
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public int StudentInsertAssignment(Assignment mod)
        {
            int rows;

            SqlParameter[] paras = { new SqlParameter("@Assignmentid", SqlDbType.VarChar ,50),
                                     new SqlParameter("@AssignmentName", SqlDbType.VarChar ,50),
                                     new SqlParameter("@submitAssiId", SqlDbType.VarChar ,50),
                                     new SqlParameter("@StartDate", SqlDbType.DateTime),
                                     new SqlParameter("@DueDate", SqlDbType.DateTime),
                                     new SqlParameter("@classid", SqlDbType.VarChar, 50),
                                     new SqlParameter("@studentid", SqlDbType.VarChar,50),
                                     new SqlParameter("@NumRows", SqlDbType.Int)
            };
            paras[0].Value = mod.AssignmentID;
            paras[1].Value = mod.AssignmentName;
            paras[2].Value = mod.SubmitAssiID;
            paras[3].Value = mod.StartDate;
            paras[4].Value = mod.DueDate;
            paras[5].Value = mod.ClassID;
            paras[6].Value = mod.StudentID;
            paras[7].Value = 0;
            //string sql = String.Format("insert into Assignment(AssignmentID,TeacherID,Outline,classID) values ('1','{0}','{1}','{2}')",mod.TeacherID,mod.Outline,mod.ClassID);
            // string sql = String.Format("insert into Assignment(AssignmentID,TeacherID,Outline,classID) values ('1','{0}','{1}','{2}',)",mod.TeacherID,mod.Outline,mod.ClassID);

            try
            {
                //rows = SqlCommand.ExecuteNonQuery(sql);
                rows = SQLHelper.ExecuteNonQuery(SQLHelper.txtConnecttionString, CommandType.StoredProcedure, "StudentInsertAssignment", paras);
                return rows;

            }
            catch (SqlException ex)
            {

                throw new Exception(ex.Message, ex);

            }

        }
    }
}