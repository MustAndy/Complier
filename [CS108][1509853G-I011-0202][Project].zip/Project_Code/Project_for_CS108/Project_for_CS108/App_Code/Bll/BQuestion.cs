﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Dal;
namespace Project_for_CS108.App_Code.Bll
{
    public class BQuestion
    {
        DQuestion dal = new DQuestion();
        public int TeacherInsertQuestion(Question w)
        {

            return dal.TeacherInsertQuestion(w);

        }
        public int StudentInsertQuestion(Question w)
        {
            return dal.StudentInsertQuestion(w);
        }



    }
}