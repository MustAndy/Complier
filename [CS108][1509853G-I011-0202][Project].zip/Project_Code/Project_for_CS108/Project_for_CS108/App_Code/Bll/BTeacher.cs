﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Dal;
namespace Project_for_CS108.App_Code.Bll
{

    public class BTeacher
    {
        DTeacher dal = new DTeacher();
        public int AdminInsertTeacher(teacher t)
        {
            return dal.AdminInsertTeacher(t);
        }
        
                public int AdminDeleteTeacher(teacher t)
        {
            return dal.AdminDeleteTeacher(t);
        }

        public bool CheckUser(string nName, string nPass)
        {

            if (string.IsNullOrEmpty(nName) || string.IsNullOrEmpty(nPass))
            {
                return false;
            }
            else
            {
                return dal.CheckUser(nName, nPass);

            }

        }

    }
}