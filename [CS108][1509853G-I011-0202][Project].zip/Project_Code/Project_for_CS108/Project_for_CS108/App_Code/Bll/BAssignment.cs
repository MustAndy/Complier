﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Dal;
namespace Project_for_CS108.App_Code.Bll
{
    public class BAssignment
    {
        DAssignment dal = new DAssignment();
        public int TeacherInsertAssignment(Assignment  t)
        {
            return dal.TeacherInsertAssignment(t);
        }
        public int StudentInsertAssignment(Assignment t)
        {

            return dal.StudentInsertAssignment(t);

        }
        //public int UpdateHomework2(Assignment t)
        //{

        //    return dal.UpdateHomework2 (t);

        //}
    }
}