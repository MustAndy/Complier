﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Dal;
namespace Project_for_CS108.App_Code.Bll
{
    public class BStudent
    {
        DStudent dal = new DStudent();
        public int TeacherInsertStudent(student st)
        {

            return dal.TeacherInsertStudent(st);

        }
        public int TeacherDeleteStudent(student st)
        {

            return dal.TeacherDeleteStudent(st);

        }

        public bool CheckUser(string nName, string nPass)
        {

            if (string.IsNullOrEmpty(nName) || string.IsNullOrEmpty(nPass))
            {
                return false;
            }
            else
            {
                return dal.CheckUser(nName, nPass);

            }

        }


     
    }
}