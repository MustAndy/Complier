﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Dal;
namespace Project_for_CS108.App_Code.Bll
{
    public class BClass
    {

        DClass dal = new DClass();
        public int AdminInsertClass(Class t)
        {
            return dal.AdminInsertClass(t);
        }
        public int AdminDeleteClass(Class t)
        {
            return dal.AdminDeleteClass(t);
        }
        public int TeacherInsertDistribute(Class t)
        {
            return dal.TeacherInsertDistribute(t);
        }

    }
}