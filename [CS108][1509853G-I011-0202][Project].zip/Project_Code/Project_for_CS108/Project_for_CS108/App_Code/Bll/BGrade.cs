﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Project_for_CS108.App_Code.Model;
using Project_for_CS108.App_Code.Dal;
namespace Project_for_CS108.App_Code.Bll
{
    public class BGrade
    {
        DGrade dal = new DGrade ();
        public int TeacherMarkGrade(Grade t)
        {
            return dal.TeacherMarkGrade(t);
        }

        public int TeacherMarkAssignment(Grade t)
        {
            return dal.TeacherMarkAssignment(t);
        }

    }
}