-- 1509853G-I011-0202  Wang,Jingqing

IF OBJECT_ID('StudentInsertQuestion', 'P') IS NOT NULL  DROP PROC StudentInsertQuestion; 
GO 
 
CREATE PROC StudentInsertQuestion 
 @Assignmentid AS varchar(50),
 @Questionid as varchar(50),
 @QuestionText   AS varchar(50),
 @Weight     AS int,
 @studentid as varchar(50),
 @questionAnswer as varchar(50),
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
insert into Question(AssignmentID,QuestionID,QuestionText,QuestionWeight,QuestionAnswer,StudentID,Submitted) 
values (@Assignmentid,@Questionid,@QuestionText,@Weight,@questionAnswer,@studentid,'1')
 
 SET @NumRows = @@rowcount;
  GO