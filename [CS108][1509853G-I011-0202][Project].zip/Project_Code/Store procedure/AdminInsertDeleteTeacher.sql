IF OBJECT_ID('AdminInsertTeacher', 'P') IS NOT NULL  DROP PROC AdminInsertTeacher; 
GO 
 
CREATE PROC AdminInsertTeacher 
 @Teacherid AS varchar(50),
 @Teachername as varchar(50),
 @Teacherpassword     AS varchar(50),
 @Teacheremails as varchar(50),
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
insert into Teacher(TeacherID,TeacherName,TeacherEmail,TeacherPassword) 
values (@Teacherid,@Teachername,@Teacheremails,@Teacherpassword)
 
 SET @NumRows = @@rowcount;
  GO

  IF OBJECT_ID('AdminDeleteTeacher', 'P') IS NOT NULL  DROP PROC AdminDeleteTeacher; 
GO 
 
CREATE PROC AdminDeleteTeacher 
 @Teacgerid AS varchar(50), 
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
 delete Assignment where Teacherid = @Teacgerid
 delete ClassInfo where teacherID = @Teacgerid
delete Teacher where TeacherID = @Teacgerid
 
 SET @NumRows = @@rowcount;
  GO