-- 1509853G-I011-0202  Wang,Jingqing

IF OBJECT_ID('TeacherMarkGrade', 'P') IS NOT NULL  DROP PROC TeacherMarkGrade; 
GO 
 
CREATE PROC TeacherMarkGrade 
 @Questionid as varchar(50),
 @QuestionMarks   AS int,
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
update Question set QuestionMarks = @QuestionMarks ,Submitted = 2 where QuestionID = @Questionid
 
 SET @NumRows = @@rowcount;
  GO
  

