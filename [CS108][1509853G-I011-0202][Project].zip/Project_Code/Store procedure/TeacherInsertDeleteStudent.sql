-- 1509853G-I011-0202  Wang,Jingqing

IF OBJECT_ID('TeacherInsertStudent', 'P') IS NOT NULL  DROP PROC TeacherInsertStudent; 
GO 
 
CREATE PROC TeacherInsertStudent 
 @Studentid AS varchar(50),
 @Studentname as varchar(50),
 @Studentmajor   AS varchar(50),
 @Studentpassword     AS varchar(50),
 @Studentemails as varchar(50),
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
insert into Student(StudentID,StudentName,StudentMajor,StudentPassword,StudentEmail) 
values (@Studentid,@Studentname,@Studentmajor,@Studentpassword,@Studentemails)
 
 SET @NumRows = @@rowcount;
  GO

  IF OBJECT_ID('TeacherDeleteStudent', 'P') IS NOT NULL  DROP PROC TeacherDeleteStudent; 
GO 
 
CREATE PROC TeacherDeleteStudent 
 @Studentid AS varchar(50), 
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
 delete Assignment where StudentID = @Studentid
 delete Distribution where studentID = @Studentid
 delete Question where StudentID = @Studentid
delete Student where StudentID = @Studentid

 
 SET @NumRows = @@rowcount;
  GO

  IF OBJECT_ID('TeacherInsertDistribute', 'P') IS NOT NULL  DROP PROC TeacherInsertDistribute; 
GO 
 
CREATE PROC TeacherInsertDistribute 
 @Classid AS varchar(50),
 @Studentid as varchar(50),
 @ClassName     AS varchar(50),
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
insert into Distribution(classID,studentID,className) 
values (@Classid,@Studentid,@ClassName)
 
 SET @NumRows = @@rowcount;
  GO