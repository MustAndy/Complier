IF OBJECT_ID('AdminInsertClass', 'P') IS NOT NULL  DROP PROC AdminInsertClass; 
GO 
 
CREATE PROC AdminInsertClass 
 @Classid AS varchar(50),
 @Teacherid as varchar(50),
 @ClassName     AS varchar(50),
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
insert into ClassInfo(classID,teacherID,className) 
values (@Classid,@Teacherid,@ClassName)
 
 SET @NumRows = @@rowcount;
  GO

  IF OBJECT_ID('AdminDeleteClass', 'P') IS NOT NULL  DROP PROC AdminDeleteClass; 
GO 
 
CREATE PROC AdminDeleteClass 
 @Classid AS varchar(50), 
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
 delete Distribution where classID = @Classid
delete ClassInfo where classID = @Classid
 
 SET @NumRows = @@rowcount;
  GO