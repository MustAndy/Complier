-- 1509853G-I011-0202  Wang,Jingqing

 IF OBJECT_ID('TeacherMarkAssignment', 'P') IS NOT NULL  DROP PROC TeacherMarkAssignment; 
GO 
 
CREATE PROC TeacherMarkAssignment 
 @assignmentID as varchar(50),
 @totalMarks   AS int,
 @comment    as varchar(50),
 @teacherid as varchar(50),
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
update Assignment set TotalMark = @totalMarks ,Comment = @comment,Teacherid = @teacherid,Submitted = 2 where AssignmentID = @assignmentID
 
 SET @NumRows = @@rowcount;
  GO