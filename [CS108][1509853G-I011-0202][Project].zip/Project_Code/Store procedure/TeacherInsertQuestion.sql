-- 1509853G-I011-0202  Wang,Jingqing

IF OBJECT_ID('TeacherInsertQuestion', 'P') IS NOT NULL  DROP PROC TeacherInsertQuestion; 
GO 
 
CREATE PROC TeacherInsertQuestion 
 @Assignmentid AS varchar(50),
 @Questionid as varchar(50),
 @QuestionText   AS varchar(50),
 @Weight     AS int,
 @submitted   AS int,
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
insert into Question(AssignmentID,QuestionID,QuestionText,QuestionWeight,Submitted) 
values (@Assignmentid,@Questionid,@QuestionText,@Weight,@submitted)
 
 SET @NumRows = @@rowcount;
  GO