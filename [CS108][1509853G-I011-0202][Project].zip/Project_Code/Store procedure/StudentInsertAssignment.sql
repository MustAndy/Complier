-- 1509853G-I011-0202  Wang,Jingqing

IF OBJECT_ID('StudentInsertAssignment', 'P') IS NOT NULL  DROP PROC StudentInsertAssignment; 
GO 
 
CREATE PROC StudentInsertAssignment 
 @Assignmentid AS varchar(50),
 @AssignmentName as varchar(50),
 @submitAssiId   AS varchar(50), 
 @StartDate as datetime,
 @DueDate as datetime,
 @classid     AS varchar(50),
 @studentid as varchar(50),
 @NumRows as INT OUTPUT 
 AS  
 SET NOCOUNT ON; 
insert into Assignment(AssignmentID,AssignmentName,SubmitAssiID,StartDate,DueDate,classid,StudentID,Submitted) 
values (@Assignmentid,@AssignmentName,@submitAssiId,@StartDate,@DueDate,@classid,@studentid,'1')
 
 SET @NumRows = @@rowcount;
  GO